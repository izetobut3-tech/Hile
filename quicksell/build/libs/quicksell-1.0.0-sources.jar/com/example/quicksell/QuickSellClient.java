package com.example.quicksell;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_124;
import net.minecraft.class_1542;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3612;
import net.minecraft.class_465;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class QuickSellClient implements ClientModInitializer {

    public static final String MOD_ID = "quicksell";
    private static final class_304.class_11900 CATEGORY = class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "main"));

    private static class_304 loopToggleKey; // G: dongu baslat/durdur
    private static class_304 stopKey;       // H: her ne olursa olsun hemen durdur

    private enum State { IDLE, COLLECTING, SELL_WAITING_FOR_GUI, SELL_CLICKING, SELL_CLOSING }

    private State state = State.IDLE;
    private boolean loopActive = false;

    private int tickCounter = 0;
    private int noItemTicks = 0;
    private int stuckTicks = 0;
    private float lastHealth = -1f;

    private int clickIndex = 0;
    private final List<Integer> targetSlots = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        QuickSellConfig.load();

        loopToggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.quicksell.loop", GLFW.GLFW_KEY_G, CATEGORY));

        stopKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.quicksell.stop", GLFW.GLFW_KEY_H, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(class_310 client) {
        var player = client.field_1724;
        if (player == null) {
            resetAll(client);
            return;
        }

        while (stopKey.method_1436()) {
            stopEverything(client, "Elle durduruldu.");
        }

        while (loopToggleKey.method_1436()) {
            if (loopActive) {
                stopEverything(client, "Dongu kapatildi.");
            } else {
                loopActive = true;
                lastHealth = player.method_6032();
                noItemTicks = 0;
                stuckTicks = 0;
                state = State.COLLECTING;
                player.method_7353(class_2561.method_43470("[QuickSell] Dongu BASLADI: topla -> envanter dolunca sat -> tekrarla")
                        .method_27692(class_124.field_1060), false);
            }
        }

        if (!loopActive) {
            return;
        }

        switch (state) {
            case COLLECTING -> tickCollecting(client, player);
            case SELL_WAITING_FOR_GUI -> handleWaitingForGui(client);
            case SELL_CLICKING -> handleClicking(client);
            case SELL_CLOSING -> handleClosing(client);
            default -> {}
        }
    }

    // =========================================================
    // TOPLAMA FAZI
    // =========================================================

    private void tickCollecting(class_310 client, class_746 player) {
        var world = client.field_1687;
        if (world == null) return;

        if (client.field_1755 != null) {
            resetMovementKeys(client);
            return;
        }

        float currentHealth = player.method_6032();
        if (lastHealth >= 0 && currentHealth < lastHealth) {
            stopEverything(client, "Hasar aldin, dongu durduruldu.");
            return;
        }
        lastHealth = currentHealth;

        if (isDangerousNearby(client, player.method_24515())) {
            stopEverything(client, "Tehlikeli blok (lav/ates) yakinda, dongu durduruldu.");
            return;
        }

        if (isInventoryFull(player)) {
            resetMovementKeys(client);
            beginSell(client, player);
            return;
        }

        double radius = QuickSellConfig.get().collectRadius;
        var wantedIds = QuickSellConfig.get().sellItemIds();

        class_1542 nearest = null;
        double nearestDistSq = Double.MAX_VALUE;
        for (var entity : world.method_8390(class_1542.class,
                player.method_5829().method_1014(radius), e -> true)) {
            class_1799 stack = entity.method_6983();
            class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
            if (!wantedIds.contains(id)) continue;
            double distSq = entity.method_5858(player);
            if (distSq < nearestDistSq) {
                nearestDistSq = distSq;
                nearest = entity;
            }
        }

        if (nearest == null) {
            resetMovementKeys(client);
            noItemTicks++;
            if (noItemTicks > QuickSellConfig.get().noItemTimeoutTicks && hasAnySellableItem(player)) {
                beginSell(client, player);
            }
            return;
        }
        noItemTicks = 0;

        class_2338 targetGroundCheck = class_2338.method_49637(nearest.method_23317(), nearest.method_23318() - 1, nearest.method_23321());
        if (world.method_8320(targetGroundCheck).method_26215()
                && world.method_8320(targetGroundCheck.method_10074()).method_26215()) {
            return;
        }

        double dx = nearest.method_23317() - player.method_23317();
        double dz = nearest.method_23321() - player.method_23321();
        float targetYaw = (float) (class_3532.method_15349(dz, dx) * (180.0 / Math.PI)) - 90f;
        player.method_36456(smoothAngle(player.method_36454(), targetYaw, 12f));
        player.method_5847(player.method_36454());

        client.field_1690.field_1894.method_23481(true);
        client.field_1690.field_1913.method_23481(false);
        client.field_1690.field_1849.method_23481(false);
        client.field_1690.field_1832.method_23481(false);

        if (player.field_5976) {
            stuckTicks++;
            client.field_1690.field_1903.method_23481(true);
            if (stuckTicks > 60) {
                stopEverything(client, "Bir engelde takildim, dongu durduruldu.");
                return;
            }
        } else {
            stuckTicks = 0;
            client.field_1690.field_1903.method_23481(false);
        }
    }

    private boolean isInventoryFull(class_746 player) {
        var inv = player.method_31548();
        for (int i = 0; i < 36; i++) {
            if (inv.method_5438(i).method_7960()) return false;
        }
        return true;
    }

    private boolean hasAnySellableItem(class_746 player) {
        var wanted = QuickSellConfig.get().sellItemIds();
        var inv = player.method_31548();
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            if (wanted.contains(class_7923.field_41178.method_10221(stack.method_7909()))) return true;
        }
        return false;
    }

    private boolean isDangerousNearby(class_310 client, class_2338 center) {
        var world = client.field_1687;
        if (world == null) return false;
        for (class_2338 pos : class_2338.method_10097(center.method_10069(-1, -1, -1), center.method_10069(1, 1, 1))) {
            var state = world.method_8320(pos);
            if (!state.method_26227().method_15769() && state.method_26227().method_15772().method_15780(class_3612.field_15908)) {
                return true;
            }
            if (state.method_27852(net.minecraft.class_2246.field_10036) || state.method_27852(net.minecraft.class_2246.field_10164)) {
                return true;
            }
        }
        return false;
    }

    private float smoothAngle(float current, float target, float maxStep) {
        float diff = class_3532.method_15393(target - current);
        diff = class_3532.method_15363(diff, -maxStep, maxStep);
        return current + diff;
    }

    // =========================================================
    // SATIS FAZI (/sellgui + shift-click)
    // =========================================================

    private void beginSell(class_310 client, class_746 player) {
        player.field_3944.method_45730(QuickSellConfig.get().sellCommand);
        state = State.SELL_WAITING_FOR_GUI;
        tickCounter = 0;
    }

    private void handleWaitingForGui(class_310 client) {
        tickCounter++;
        if (client.field_1755 instanceof class_465<?> handledScreen) {
            String title = handledScreen.method_25440().getString();
            if (title.contains(QuickSellConfig.get().guiTitleContains)) {
                if (tickCounter >= QuickSellConfig.get().openDelayTicks) {
                    prepareClicks(client, handledScreen.method_17577());
                    state = State.SELL_CLICKING;
                    tickCounter = 0;
                }
                return;
            }
        }
        if (tickCounter > 100) {
            stopEverything(client, "sellgui menusu acilmadi, dongu durduruldu.");
        }
    }

    private void prepareClicks(class_310 client, class_1703 handler) {
        targetSlots.clear();
        clickIndex = 0;
        var wanted = QuickSellConfig.get().sellItemIds();
        for (class_1735 slot : handler.field_7761) {
            if (!slot.field_7871.equals(client.field_1724.method_31548())) continue;
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;
            class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
            if (wanted.contains(id)) {
                targetSlots.add(slot.field_7874);
            }
        }
    }

    private void handleClicking(class_310 client) {
        if (!(client.field_1755 instanceof class_465<?> handledScreen)) {
            state = State.COLLECTING;
            return;
        }
        tickCounter++;
        if (tickCounter < QuickSellConfig.get().clickDelayTicks) return;
        tickCounter = 0;

        if (clickIndex >= targetSlots.size()) {
            state = State.SELL_CLOSING;
            return;
        }

        int slotId = targetSlots.get(clickIndex);
        class_1703 handler = handledScreen.method_17577();
        client.field_1761.method_2906(handler.field_7763, slotId, 0, class_1713.field_7794, client.field_1724);
        clickIndex++;
    }

    private void handleClosing(class_310 client) {
        tickCounter++;
        if (tickCounter < QuickSellConfig.get().closeDelayTicks) return;
        if (client.field_1724 != null) {
            client.field_1724.method_7346();
        }
        client.method_1507(null);

        if (loopActive) {
            noItemTicks = 0;
            stuckTicks = 0;
            lastHealth = client.field_1724 != null ? client.field_1724.method_6032() : -1f;
            state = State.COLLECTING;
        } else {
            state = State.IDLE;
        }
    }

    // =========================================================
    // YARDIMCI
    // =========================================================

    private void resetMovementKeys(class_310 client) {
        client.field_1690.field_1894.method_23481(false);
        client.field_1690.field_1913.method_23481(false);
        client.field_1690.field_1849.method_23481(false);
        client.field_1690.field_1903.method_23481(false);
        client.field_1690.field_1832.method_23481(false);
    }

    private void stopEverything(class_310 client, String reason) {
        loopActive = false;
        state = State.IDLE;
        resetMovementKeys(client);
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("[QuickSell] " + reason).method_27692(class_124.field_1061), false);
        }
    }

    private void resetAll(class_310 client) {
        loopActive = false;
        state = State.IDLE;
    }
}
